package com.bakr.quranlisten

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.PowerManager
import java.io.File

/**
 * خدمة تشغيل أمامية: تكمل التلاوة بعد إغلاق الشاشة أو الخروج من التطبيق،
 * وتعرض إشعارًا فيه أزرار (السابق / تشغيل-إيقاف / التالي / إغلاق).
 */
class PlaybackService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): PlaybackService = this@PlaybackService
    }

    interface Listener {
        fun onStateChanged()
    }

    private val binder = LocalBinder()
    private var player: MediaPlayer? = null
    private var session: MediaSession? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null
    private var resumeAfterFocusLoss = false
    private var isForeground = false

    var listener: Listener? = null

    private val handler = Handler(Looper.getMainLooper())
    private var pendingSeek = 0

    // مؤقّت النوم
    private var sleepEndsAt = 0L
    var sleepAfterTrack = false
        private set
    val sleepRemainingMs: Long
        get() = if (sleepEndsAt > 0) maxOf(0L, sleepEndsAt - SystemClock.elapsedRealtime()) else 0L
    private val sleepRunnable = Runnable { clearSleep(); pause() }

    // حفظ آخر موضع
    private val saveRunnable = object : Runnable {
        override fun run() {
            if (isPlaying) savePosition()
            handler.postDelayed(this, 5000)
        }
    }

    var playlist: List<File> = emptyList()
        private set
    var index: Int = -1
        private set
    var isPrepared: Boolean = false
        private set

    val currentFile: File? get() = playlist.getOrNull(index)
    val currentTitle: String get() = currentFile?.let { Catalog.titleFor(this, it) } ?: "القرآن الكريم"
    private val currentReader: String get() = currentFile?.let { Catalog.readerNameFor(this, it) } ?: "تلاوة مجوّدة"
    private var metaPath: String? = null
    val isPlaying: Boolean get() = isPrepared && (player?.isPlaying == true)
    val position: Int get() = if (isPrepared) player?.currentPosition ?: 0 else 0
    val duration: Int get() = if (isPrepared) player?.duration ?: 0 else 0

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) pause()
        }
    }
    private var noisyRegistered = false

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        createChannel()
        session = MediaSession(this, "QuranListening").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() = resume()
                override fun onPause() = pause()
                override fun onSkipToNext() = next()
                override fun onSkipToPrevious() = previous()
                override fun onSeekTo(pos: Long) = seekTo(pos.toInt())
                override fun onStop() = stopAndClose()
            })
            isActive = true
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> if (isPlaying) pause() else resume()
            ACTION_NEXT -> next()
            ACTION_PREV -> previous()
            ACTION_STOP -> stopAndClose()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ التحكم

    fun playList(files: List<File>, startIndex: Int, startPositionMs: Int = 0) {
        if (files.isEmpty() || startIndex !in files.indices) return
        playlist = files
        pendingSeek = startPositionMs
        playIndex(startIndex)
    }

    private fun playIndex(i: Int) {
        if (i !in playlist.indices) return
        index = i
        isPrepared = false
        releasePlayer()
        if (!requestFocus()) {
            notifyState()
            return
        }
        // لازم نبدأ الخدمة كخدمة أمامية قبل ما نشغّل
        startService(Intent(this, PlaybackService::class.java))
        showNotification()
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(playlist[i].absolutePath)
                setOnPreparedListener {
                    isPrepared = true
                    if (pendingSeek in 1 until it.duration) it.seekTo(pendingSeek)
                    pendingSeek = 0
                    it.start()
                    registerNoisy()
                    handler.removeCallbacks(saveRunnable)
                    handler.postDelayed(saveRunnable, 5000)
                    showNotification()
                    notifyState()
                }
                setOnCompletionListener {
                    savePosition(0) // خلصت التلاوة: المرة الجاية تبدأ من أولها
                    if (!sleepAfterTrack && index < playlist.lastIndex) next() else {
                        clearSleep()
                        isPrepared = true
                        unregisterNoisy()
                        showNotification()
                        notifyState()
                        stopForegroundKeepNotification()
                    }
                }
                setOnErrorListener { _, _, _ ->
                    isPrepared = false
                    if (index < playlist.lastIndex) next() else notifyState()
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            isPrepared = false
        }
        notifyState()
    }

    fun resume() {
        val p = player ?: return
        if (!isPrepared) return
        if (!requestFocus()) return
        // لو التلاوة خلصت وضغط تشغيل نبدأها من الأول
        if (p.currentPosition >= p.duration - 300) p.seekTo(0)
        p.start()
        registerNoisy()
        showNotification()
        notifyState()
    }

    fun pause() {
        val p = player ?: return
        if (isPrepared && p.isPlaying) p.pause()
        savePosition()
        unregisterNoisy()
        showNotification()
        stopForegroundKeepNotification()
        notifyState()
    }

    fun next() {
        if (index < playlist.lastIndex) playIndex(index + 1)
    }

    fun previous() {
        // لو عدّى أكتر من 4 ثواني نرجع لبداية نفس التلاوة، وإلا للسابقة
        if (position > 4000 || index == 0) seekTo(0) else playIndex(index - 1)
    }

    fun seekTo(ms: Int) {
        if (isPrepared) {
            player?.seekTo(ms)
            updateSession()
            notifyState()
        }
    }

    fun stopAndClose() {
        savePosition()
        handler.removeCallbacks(saveRunnable)
        clearSleep()
        releasePlayer()
        abandonFocus()
        unregisterNoisy()
        isPrepared = false
        playlist = emptyList()
        index = -1
        if (isForeground) removeForeground(true)
        isForeground = false
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID)
        notifyState()
        stopSelf()
    }

    // ------------------------------------------------------------------ مؤقّت النوم وحفظ الموضع

    fun setSleepTimer(minutes: Int) {
        clearSleep()
        if (minutes > 0) {
            sleepEndsAt = SystemClock.elapsedRealtime() + minutes * 60_000L
            handler.postDelayed(sleepRunnable, minutes * 60_000L)
        }
        notifyState()
    }

    fun sleepAfterCurrentTrack() {
        clearSleep()
        sleepAfterTrack = true
        notifyState()
    }

    fun clearSleep() {
        handler.removeCallbacks(sleepRunnable)
        sleepEndsAt = 0L
        sleepAfterTrack = false
    }

    private fun savePosition(overrideMs: Int? = null) {
        val file = currentFile ?: return
        val pos = overrideMs ?: position
        getSharedPreferences(PLAYBACK_PREFS, MODE_PRIVATE).edit()
            .putString(KEY_LAST_PATH, file.absolutePath)
            .putInt(KEY_LAST_POS, pos)
            .apply()
    }

    private fun releasePlayer() {
        player?.setOnPreparedListener(null)
        player?.setOnCompletionListener(null)
        player?.setOnErrorListener(null)
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun notifyState() {
        updateSession()
        listener?.onStateChanged()
    }

    // ------------------------------------------------------------------ تركيز الصوت

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { resumeAfterFocusLoss = false; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeAfterFocusLoss = isPlaying
                if (isPlaying) pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.setVolume(0.3f, 0.3f)
            AudioManager.AUDIOFOCUS_GAIN -> {
                player?.setVolume(1f, 1f)
                if (resumeAfterFocusLoss) { resumeAfterFocusLoss = false; resume() }
            }
        }
    }

    private fun requestFocus(): Boolean {
        val am = audioManager ?: return true
        val result = if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            focusRequest = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(focusListener)
        }
    }

    private fun registerNoisy() {
        if (!noisyRegistered) {
            registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
            noisyRegistered = true
        }
    }

    private fun unregisterNoisy() {
        if (noisyRegistered) {
            try { unregisterReceiver(noisyReceiver) } catch (_: Exception) {}
            noisyRegistered = false
        }
    }

    // ------------------------------------------------------------------ الإشعار وجلسة الوسائط

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "تشغيل التلاوات", NotificationManager.IMPORTANCE_LOW)
            channel.setShowBadge(false)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun actionIntent(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, PlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = currentTitle
        val playing = isPlaying
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else @Suppress("DEPRECATION") Notification.Builder(this)

        builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(currentReader)
            .setContentIntent(openApp)
            .setOngoing(playing)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "السابق", actionIntent(ACTION_PREV, 1)).build())
            .addAction(
                Notification.Action.Builder(
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                    if (playing) "إيقاف مؤقت" else "تشغيل",
                    actionIntent(ACTION_TOGGLE, 2)
                ).build()
            )
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "التالي", actionIntent(ACTION_NEXT, 3)).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "إغلاق", actionIntent(ACTION_STOP, 4)).build())
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(session?.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        return builder.build()
    }

    private fun showNotification() {
        val notification = buildNotification()
        if (isPlaying || !isForeground) {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, notification)
            }
            isForeground = true
        } else {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notification)
        }
    }

    /** عند الإيقاف المؤقت نترك الإشعار ظاهرًا لكن نسمح بإزالته بالسحب. */
    private fun stopForegroundKeepNotification() {
        if (isForeground) {
            removeForeground(false)
            isForeground = false
        }
    }

    /** STOP_FOREGROUND_* متاحة من API 24 فقط، والتطبيق minSdk 23. */
    @Suppress("DEPRECATION")
    private fun removeForeground(removeNotification: Boolean) {
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(if (removeNotification) Service.STOP_FOREGROUND_REMOVE else Service.STOP_FOREGROUND_DETACH)
        } else {
            stopForeground(removeNotification)
        }
    }

    private fun updateSession() {
        val s = session ?: return
        val state = when {
            currentFile == null -> PlaybackState.STATE_NONE
            !isPrepared -> PlaybackState.STATE_BUFFERING
            isPlaying -> PlaybackState.STATE_PLAYING
            else -> PlaybackState.STATE_PAUSED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
            PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP
        val f = currentFile
        if (f?.absolutePath != metaPath) {
            metaPath = f?.absolutePath
            if (f != null) {
                s.setMetadata(
                    MediaMetadata.Builder()
                        .putString(MediaMetadata.METADATA_KEY_TITLE, currentTitle)
                        .putString(MediaMetadata.METADATA_KEY_ARTIST, currentReader)
                        .build()
                )
            }
        }
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(actions)
                .setState(state, position.toLong(), if (isPlaying) 1f else 0f)
                .build()
        )
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // لو المستخدم شال التطبيق من الأخيرة والتشغيل واقف، نقفل الخدمة
        if (!isPlaying) stopAndClose()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        unregisterNoisy()
        releasePlayer()
        abandonFocus()
        session?.release()
        session = null
        super.onDestroy()
    }

    companion object {
        const val PLAYBACK_PREFS = "playback"
        const val KEY_LAST_PATH = "last_path"
        const val KEY_LAST_POS = "last_pos"
        const val CHANNEL_ID = "playback"
        const val NOTIF_ID = 1001
        const val ACTION_TOGGLE = "com.bakr.quranlisten.TOGGLE"
        const val ACTION_NEXT = "com.bakr.quranlisten.NEXT"
        const val ACTION_PREV = "com.bakr.quranlisten.PREV"
        const val ACTION_STOP = "com.bakr.quranlisten.STOP"
    }
}
