package com.bakr.quranlisten

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * ينزّل التلاوات واحدة بعد الأخرى (مقطع مقطع) في خدمة أمامية، فلا يتعلق التنزيل بفتح التطبيق.
 * كل ملف يُحفظ كـ ‎.part‎ أثناء التنزيل ويُستأنف من حيث وقف عند الانقطاع، ثم يُنقل لاسمه النهائي عند اكتماله.
 */
class DownloadService : Service() {

    data class Job(val readerId: String, val name: String, val size: Long, val url: String, val label: String = "") {
        val key: String get() = "$readerId/$name"
        val shownName: String get() = label.ifBlank { File(name).nameWithoutExtension }
    }

    interface Listener { fun onDownloadChanged() }

    inner class LocalBinder : Binder() {
        fun getService(): DownloadService = this@DownloadService
    }

    private val binder = LocalBinder()
    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val queue = ArrayDeque<Job>()
    private var running = false // محمي بـ lock
    private var isForeground = false

    @Volatile private var cancelled = false
    @Volatile private var stoppedByUser = false

    var listener: Listener? = null

    @Volatile var current: Job? = null
        private set
    @Volatile var currentBytes = 0L
        private set
    @Volatile var currentTotal = 0L
        private set
    @Volatile var lastError: String? = null
        private set
    @Volatile var doneCount = 0
        private set
    @Volatile var failedCount = 0
        private set

    val queuedCount: Int get() = synchronized(lock) { queue.size }
    val isBusy: Boolean get() = synchronized(lock) { running || queue.isNotEmpty() }
    fun isBusyFor(readerId: String): Boolean =
        current?.readerId == readerId || synchronized(lock) { queue.any { it.readerId == readerId } }
    fun isQueued(key: String): Boolean = synchronized(lock) { queue.any { it.key == key } }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "تنزيل التلاوات", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) cancelAll()
        return START_NOT_STICKY
    }

    /** أندرويد 15 يحدّد مدة لخدمات dataSync الأمامية؛ نوقف بهدوء ويمكن الاستكمال لاحقًا. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        lastError = "أوقف النظام التنزيل مؤقتًا. اضغط «تنزيل المتبقي» لاستكماله."
        cancelAll()
        stopSelf()
    }

    // ------------------------------------------------------------------ واجهة الاستخدام

    fun enqueue(jobs: List<Job>) {
        var added = 0
        var startWorker = false
        synchronized(lock) {
            for (j in jobs) {
                if (isDownloaded(j)) continue
                if (current?.key == j.key || queue.any { it.key == j.key }) continue
                queue.addLast(j); added++
            }
            if (added > 0 && !running) { running = true; startWorker = true }
        }
        if (added == 0) { notifyChanged(); return }
        if (startWorker) {
            doneCount = 0; failedCount = 0; lastError = null; stoppedByUser = false
            startService(Intent(this, DownloadService::class.java))
            startFg(buildNotification("جارٍ التحضير للتنزيل...", 0, true))
            Thread { runQueue() }.start()
        }
        notifyChanged()
    }

    fun cancelAll() {
        synchronized(lock) { queue.clear() }
        stoppedByUser = true
        cancelled = true
        notifyChanged()
    }

    fun cancelReader(readerId: String) {
        val hadQueued = synchronized(lock) { queue.removeAll { it.readerId == readerId } }
        val currentAffected = current?.readerId == readerId
        if (hadQueued || currentAffected) stoppedByUser = true
        if (currentAffected) cancelled = true
        notifyChanged()
    }

    // ------------------------------------------------------------------ العمل في الخلفية

    private fun isDownloaded(j: Job): Boolean {
        val f = Catalog.safeFile(this, j.readerId, j.name) ?: return false
        return f.isFile && f.length() > 0
    }

    private fun runQueue() {
        var consecutiveFailures = 0
        while (true) {
            val job = synchronized(lock) {
                val j = queue.removeFirstOrNull()
                if (j == null) running = false
                j
            } ?: break

            cancelled = false
            current = job; currentBytes = 0L; currentTotal = job.size
            notifyChanged()

            var ok = false
            var attempt = 0
            while (attempt < 3 && !ok) {
                attempt++
                try {
                    download(job)
                    ok = true
                } catch (e: Exception) {
                    if (cancelled) break
                    lastError = e.localizedMessage ?: e.javaClass.simpleName
                    if (attempt < 3) try { Thread.sleep(3000) } catch (_: InterruptedException) {}
                }
            }
            val wasCancelled = cancelled
            current = null
            if (ok) {
                doneCount++; consecutiveFailures = 0; lastError = null
            } else if (!wasCancelled) {
                failedCount++; consecutiveFailures++
                if (consecutiveFailures >= 2) {
                    synchronized(lock) { queue.clear() }
                    lastError = "تعذّر الاتصال بالمصدر. تم إيقاف التنزيل، ويمكنك استكماله لاحقًا."
                }
            }
            notifyChanged()
        }
        handler.post { finishIfIdle() }
    }

    private fun download(job: Job) {
        val out = Catalog.safeFile(this, job.readerId, job.name) ?: throw IOException("مسار ملف غير صالح")
        if (out.isFile && out.length() > 0) return
        out.parentFile?.mkdirs()
        val part = File(out.path + ".part")
        var existing = if (part.exists()) part.length() else 0L

        val conn = (URL(job.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000; readTimeout = 30000; instanceFollowRedirects = true
            setRequestProperty("User-Agent", "QuranListening/1.0")
            if (existing > 0) setRequestProperty("Range", "bytes=$existing-")
        }
        try {
            val code = conn.responseCode
            if (code == 416) { part.delete(); throw IOException("إعادة التنزيل من البداية") }
            if (code != 200 && code != 206) throw IOException("خطأ من الخادم (HTTP $code)")
            val append = code == 206
            if (!append) existing = 0L
            val len = conn.contentLengthLong
            val total = if (len > 0) existing + len else job.size
            currentTotal = total
            currentBytes = existing

            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { output ->
                    val buf = ByteArray(64 * 1024)
                    var lastTick = 0L
                    while (true) {
                        if (cancelled) throw IOException("cancelled")
                        val read = input.read(buf)
                        if (read < 0) break
                        output.write(buf, 0, read)
                        currentBytes += read
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastTick > 700) { lastTick = now; progressTick() }
                    }
                }
            }
            if (total > 0 && part.length() != total) throw IOException("الملف غير مكتمل")
            if (!part.renameTo(out)) throw IOException("تعذر حفظ الملف")
        } finally {
            conn.disconnect()
        }
    }

    // ------------------------------------------------------------------ الإشعارات

    private fun progressTick() {
        val job = current ?: return
        val total = currentTotal
        val pct = if (total > 0) (currentBytes * 100 / total).toInt() else 0
        val n = buildNotification(
            "${job.shownName} — $pct% (المتبقي $queuedCount)",
            pct, total <= 0
        )
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, n)
        notifyChanged()
    }

    private fun buildNotification(text: String, pct: Int, indeterminate: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 11,
            Intent(this, DownloadService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("تنزيل التلاوات")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, indeterminate)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stop).build())
            .build()
    }

    private fun startFg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NOTIF_ID, n)
        isForeground = true
    }

    private fun finishIfIdle() {
        val idle = synchronized(lock) { !running && queue.isEmpty() }
        if (!idle) return
        if (isForeground) {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
            isForeground = false
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIF_ID)
        val msg = when {
            stoppedByUser -> null
            failedCount > 0 -> "اكتمل التنزيل مع تعذّر $failedCount تلاوة."
            doneCount > 0 -> "اكتمل تنزيل $doneCount تلاوة."
            else -> null
        }
        if (msg != null) {
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
            else @Suppress("DEPRECATION") Notification.Builder(this)
            nm.notify(
                DONE_ID,
                b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("التلاوات المجوّدة")
                    .setContentText(msg)
                    .setAutoCancel(true)
                    .setContentIntent(
                        PendingIntent.getActivity(
                            this, 1,
                            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                    )
                    .build()
            )
        }
        notifyChanged()
        stopSelf()
    }

    private fun notifyChanged() {
        handler.post { listener?.onDownloadChanged() }
    }

    override fun onDestroy() {
        cancelled = true
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "download"
        const val NOTIF_ID = 2001
        const val DONE_ID = 2002
        const val ACTION_STOP = "com.bakr.quranlisten.DL_STOP"
    }
}
