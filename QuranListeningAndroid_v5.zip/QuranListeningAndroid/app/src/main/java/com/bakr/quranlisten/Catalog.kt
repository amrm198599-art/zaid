package com.bakr.quranlisten

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Reader(val id: String, val name: String, val details: String, val identifier: String)

/** تلاوة واحدة على Archive.org: اسم الملف وحجمه بالبايت (0 لو غير معروف). */
data class RemoteTrack(val name: String, val size: Long, val title: String = "")

object Catalog {

    val AUDIO_EXT = setOf("mp3", "m4a", "ogg")

    val readers = listOf(
        Reader(
            "shahat",
            "الشيخ الشحات محمد أنور",
            "تلاوات مجوّدة مختارة • نزّل ما تريد تلاوة تلاوة",
            "shohatanwarm3raj"
        ),
        Reader(
            "mamdooh",
            "الشيخ ممدوح عامر",
            "تلاوات وحفلات مجوّدة مختارة • نزّل ما تريد تلاوة تلاوة",
            "mp3---quran----telawat--by---mamdoo7----3amer"
        )
    )

    fun downloadUrl(identifier: String, name: String): String =
        "https://archive.org/download/$identifier/" + Uri.encode(name, "/")

    fun sourceUrl(identifier: String): String = "https://archive.org/details/$identifier"

    fun audioDir(ctx: Context, readerId: String): File = File(ctx.filesDir, "audio/$readerId")

    /** مسار الملف المحلي، أو null لو الاسم يحاول الخروج من مجلد القارئ. */
    fun safeFile(ctx: Context, readerId: String, name: String): File? {
        val base = audioDir(ctx, readerId)
        val f = File(base, name)
        return if (f.canonicalPath.startsWith(base.canonicalPath + File.separator)) f else null
    }

    fun isDownloaded(ctx: Context, readerId: String, name: String): Boolean =
        safeFile(ctx, readerId, name)?.let { it.isFile && it.length() > 0 } == true

    fun downloadedCount(ctx: Context, readerId: String): Int =
        audioDir(ctx, readerId).walkTopDown().count { it.isFile && it.extension.lowercase() in AUDIO_EXT }

    private fun cacheFile(ctx: Context, readerId: String) = File(ctx.filesDir, "catalog/$readerId.json")

    fun loadCached(ctx: Context, readerId: String): List<RemoteTrack>? {
        val f = cacheFile(ctx, readerId)
        if (!f.isFile) return null
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RemoteTrack(o.getString("n"), o.optLong("s", 0L), o.optString("t", ""))
            }.takeIf { it.isNotEmpty() }
        } catch (_: Exception) { null }
    }

    /** يجلب قائمة ملفات MP3 من Archive.org (عملية شبكة: لا تُستدعى على الخيط الرئيسي). */
    fun fetch(ctx: Context, reader: Reader): List<RemoteTrack> {
        val conn = (URL("https://archive.org/metadata/${reader.identifier}").openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000; readTimeout = 40000; instanceFollowRedirects = true
            setRequestProperty("User-Agent", "QuranListening/1.0")
        }
        val text = try {
            if (conn.responseCode != 200) throw IOException("تعذر جلب قائمة التلاوات (HTTP ${conn.responseCode})")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally { conn.disconnect() }

        val files = JSONObject(text).optJSONArray("files") ?: throw IOException("قائمة الملفات غير موجودة في المصدر")
        val raw = (0 until files.length()).map { files.getJSONObject(it) }
            .filter { it.optString("name").lowercase().endsWith(".mp3") }
            // نفضّل الملف الأصلي على المشتق لو وُجد الاثنان بنفس الاسم
            .sortedByDescending { it.optString("source") == "original" }
        val seen = HashSet<String>()
        val tracks = raw.mapNotNull { o ->
            val name = o.getString("name")
            val key = name.substringBeforeLast('.').lowercase()
            if (!seen.add(key)) null else RemoteTrack(name, o.optString("size").toLongOrNull() ?: 0L, o.optString("title").trim())
        }
        if (tracks.isEmpty()) throw IOException("لم يتم العثور على ملفات MP3 في المصدر")

        try {
            val f = cacheFile(ctx, reader.id)
            f.parentFile?.mkdirs()
            val arr = JSONArray()
            tracks.forEach { arr.put(JSONObject().put("n", it.name).put("s", it.size).put("t", it.title)) }
            f.writeText(arr.toString())
            synchronized(titleCache) { titleCache.remove(reader.id) }
        } catch (_: Exception) {}
        return tracks
    }


    // ------------------------------------------------------------------ أسماء العرض

    private val SURAHS = listOf(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
        "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
        "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
        "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
        "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
        "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
        "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
        "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
        "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
        "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
        "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
        "المسد", "الإخلاص", "الفلق", "الناس"
    )

    /** الاسم المعروض: عنوان الملف في Archive لو وُجد، أو اسم السورة لو الملف رقم (001..114)، وإلا اسم الملف. */
    fun displayName(name: String, title: String?): String {
        if (!title.isNullOrBlank()) return title.trim()
        val base = File(name).nameWithoutExtension
        val n = base.toIntOrNull()
        if (n != null && n in 1..SURAHS.size) return "سورة " + SURAHS[n - 1]
        return base
    }

    private val titleCache = HashMap<String, Map<String, String>>()

    /** الاسم المعروض لملف محفوظ محليًا (من القائمة المخزّنة، بدون شبكة). */
    fun titleFor(ctx: Context, file: File): String {
        val root = File(ctx.filesDir, "audio").absolutePath + File.separator
        val path = file.absolutePath
        if (!path.startsWith(root)) return file.nameWithoutExtension
        val rel = path.removePrefix(root)
        val readerId = rel.substringBefore(File.separator)
        val name = rel.substringAfter(File.separator, "")
        val map = synchronized(titleCache) {
            titleCache.getOrPut(readerId) {
                loadCached(ctx, readerId)?.associate { it.name to it.title } ?: emptyMap()
            }
        }
        return displayName(name, map[name])
    }

    fun readerNameFor(ctx: Context, file: File): String? =
        readers.firstOrNull { file.absolutePath.startsWith(audioDir(ctx, it.id).absolutePath + File.separator) }?.name

    /** توحيد النص العربي للبحث: بدون تشكيل، وتوحيد الألف والياء والتاء المربوطة. */
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when (ch) {
                in '\u064B'..'\u065F', '\u0670', '\u0640' -> {}
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ى' -> sb.append('ي')
                'ة' -> sb.append('ه')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** ترتيب طبيعي: 2 قبل 10. */
    fun compareNatural(a: String, b: String): Int {
        var i = 0; var j = 0
        while (i < a.length && j < b.length) {
            if (a[i].isDigit() && b[j].isDigit()) {
                val si = i; while (i < a.length && a[i].isDigit()) i++
                val sj = j; while (j < b.length && b[j].isDigit()) j++
                val na = a.substring(si, i).trimStart('0'); val nb = b.substring(sj, j).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb); if (c != 0) return c
            } else {
                val c = a[i].lowercaseChar().compareTo(b[j].lowercaseChar()); if (c != 0) return c
                i++; j++
            }
        }
        return (a.length - i) - (b.length - j)
    }
}
