package com.bakr.quranlisten

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File

class MainActivity : Activity(), PlaybackService.Listener, DownloadService.Listener {

    private val dark = 0xFF102C25.toInt()
    private val cream = 0xFFF7F5EF.toInt()
    private val gold = 0xFFF4D58A.toInt()

    // الواجهة العامة
    private lateinit var content: ViewGroup
    private lateinit var statusText: TextView
    private lateinit var playerBar: LinearLayout
    private lateinit var playerTitle: TextView
    private lateinit var playerTime: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlay: ImageButton
    private var seekDragging = false

    // شاشة قائمة التلاوات
    private var openReader: Reader? = null
    private var allTracks: List<RemoteTrack> = emptyList()
    private var shownTracks: List<RemoteTrack> = emptyList()
    private var trackAdapter: TrackAdapter? = null
    private var dlButton: Button? = null
    private var summaryText: TextView? = null
    private val downloadedSet = HashSet<String>() // أسماء الملفات المحفوظة للقارئ المفتوح (بدون فحص القرص عند كل رسم)
    private var lastDone = -1
    private var inVideos = false
    private var videoAdapter: VideoAdapter? = null
    private var videoList: List<VideoItem> = emptyList()

    // الخدمات
    private var service: PlaybackService? = null
    private var dl: DownloadService? = null
    private var wasBusy = false

    private val playConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as PlaybackService.LocalBinder).getService().also { it.listener = this@MainActivity }
            onStateChanged()
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null }
    }
    private val dlConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            dl = (binder as DownloadService.LocalBinder).getService().also { it.listener = this@MainActivity }
            refreshDownloadUi()
        }
        override fun onServiceDisconnected(name: ComponentName?) { dl = null }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            updatePlayerBar()
            refreshDownloadUi()
            handler.postDelayed(this, 700)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: RemoteTrack) = Catalog.displayName(t.name, t.title)

    private fun rescanDownloaded() {
        val r = openReader ?: return
        downloadedSet.clear()
        allTracks.forEach { if (Catalog.isDownloaded(this, r.id, it.name)) downloadedSet.add(it.name) }
    }

    // ------------------------------------------------------------------ دورة الحياة

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        showHome()

        bindService(Intent(this, PlaybackService::class.java), playConnection, Context.BIND_AUTO_CREATE)
        bindService(Intent(this, DownloadService::class.java), dlConnection, Context.BIND_AUTO_CREATE)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)

        // التنويه يظهر عند كل فتح للتطبيق (وليس عند تدوير الشاشة)
        if (savedInstanceState == null) showSadaqaDialog()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
        onStateChanged()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        service?.listener = null
        dl?.listener = null
        try { unbindService(playConnection) } catch (_: Exception) {}
        try { unbindService(dlConnection) } catch (_: Exception) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (openReader != null || inVideos) showHome() else super.onBackPressed()
    }

    private fun showSadaqaDialog() {
        AlertDialog.Builder(this)
            .setTitle("صدقة جارية")
            .setMessage(
                "هذا التطبيق صدقة جارية على أرواح المسلمين أجمعين في كل مكان.\n\n" +
                    "اللهم ارحمهم واغفر لهم، وتقبّل منّا ومنهم.\n\n" +
                    "شارك التطبيق مع أهلك وأصدقائك ليعمّ الأجر."
            )
            .setPositiveButton("آمين", null)
            .setNeutralButton("مشاركة التطبيق") { _, _ -> shareInstalledApk() }
            .show()
    }

    // ------------------------------------------------------------------ بناء الواجهة

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(dark) // لون خلف شريط الحالة وشريط التنقل (Edge-to-edge في أندرويد 15)
        }
        ViewCompat.setOnApplyWindowInsetsListener(outer) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        content = LinearLayout(this).apply { setBackgroundColor(cream) }
        outer.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        statusText = TextView(this).apply {
            text = "جاهز"; textSize = 13f; setTextColor(0xFF37564B.toInt())
            setPadding(dp(14), dp(6), dp(14), dp(6)); setBackgroundColor(0xFFE9E5D8.toInt())
        }
        outer.addView(statusText, LinearLayout.LayoutParams(-1, -2))

        playerBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            visibility = View.GONE
        }
        playerTitle = TextView(this).apply {
            textSize = 15f; setTextColor(gold); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MARQUEE; isSelected = true
        }
        playerBar.addView(playerTitle)
        seekBar = SeekBar(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) playerTime.text = "${fmt(p)} / ${fmt(sb?.max ?: 0)}"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { seekDragging = true }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    seekDragging = false
                    service?.seekTo(sb?.progress ?: 0)
                }
            })
        }
        playerBar.addView(seekBar, LinearLayout.LayoutParams(-1, -2))
        playerTime = TextView(this).apply { textSize = 12f; setTextColor(0xFFCFCBB9.toInt()); layoutDirection = View.LAYOUT_DIRECTION_LTR }
        playerBar.addView(playerTime)

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        fun ctl(icon: Int, desc: String, onClick: () -> Unit) = ImageButton(this).apply {
            setImageResource(icon); setColorFilter(gold); contentDescription = desc
            setBackgroundColor(Color.TRANSPARENT); setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { onClick() }
        }
        controls.addView(ctl(android.R.drawable.ic_media_previous, "السابق") { service?.previous() })
        btnPlay = ctl(android.R.drawable.ic_media_play, "تشغيل / إيقاف") {
            service?.let { if (it.isPlaying) it.pause() else it.resume() }
        }
        controls.addView(btnPlay)
        controls.addView(ctl(android.R.drawable.ic_media_next, "التالي") { service?.next() })
        controls.addView(ctl(android.R.drawable.ic_lock_idle_alarm, "مؤقّت النوم") { showSleepDialog() })
        controls.addView(ctl(android.R.drawable.ic_menu_close_clear_cancel, "إغلاق") { service?.stopAndClose() })
        playerBar.addView(controls, LinearLayout.LayoutParams(-1, -2))
        outer.addView(playerBar, LinearLayout.LayoutParams(-1, -2))

        setContentView(outer)
    }

    private fun setContent(view: View) {
        content.removeAllViews()
        content.addView(view, ViewGroup.LayoutParams(-1, -1))
    }

    // ------------------------------------------------------------------ الشاشة الرئيسية

    private fun showHome() {
        openReader = null
        inVideos = false; videoAdapter = null
        trackAdapter = null; dlButton = null; summaryText = null
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(20)) }
        val scroll = ScrollView(this).apply { addView(root) }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(dark)
            setPadding(dp(16), dp(24), dp(16), dp(20))
        }
        header.addView(TextView(this).apply {
            text = "القرآن الكريم\nاستماع فقط • تلاوات مجوّدة"
            textSize = 25f; gravity = Gravity.CENTER; setTextColor(gold)
        }, LinearLayout.LayoutParams(-1, -2))
        header.addView(TextView(this).apply {
            text = "صدقة جارية على أرواح المسلمين أجمعين في كل مكان"
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFFCFE3D8.toInt()); setPadding(0, dp(10), 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(header, LinearLayout.LayoutParams(-1, -2).apply { setMargins(-dp(14), 0, -dp(14), 0) })

        root.addView(TextView(this).apply {
            text = "استمع إلى التلاوات المجوّدة فقط دون عرض المصحف أو نص الآيات. اختر القارئ ثم نزّل ما تريد تلاوة تلاوة (أو كلها دفعة واحدة)؛ وبعد الحفظ تستمع دون إنترنت. هذه مجموعات تلاوات مختارة وليست ختمة كاملة من 114 سورة."
            textSize = 16f; setTextColor(0xFF263A33.toInt()); setPadding(dp(4), dp(16), dp(4), dp(12))
        })

        // زر مشاركة التطبيق ظاهر في أعلى الصفحة
        root.addView(Button(this).apply {
            text = "مشاركة التطبيق (APK) مع أهلك وأصدقائك"
            setOnClickListener { shareInstalledApk() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        lastPlayed()?.let { (file, pos) ->
            root.addView(Button(this).apply {
                text = "تابع من حيث توقفت\n${Catalog.titleFor(this@MainActivity, file)} (${fmt(pos)})"
                setOnClickListener { resumeLast(file, pos) }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        }

        Catalog.readers.forEach { reader ->
            val saved = Catalog.downloadedCount(this, reader.id)
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
                setBackgroundColor(Color.WHITE)
            }
            card.addView(TextView(this).apply { text = reader.name; textSize = 20f; setTextColor(0xFF153B30.toInt()) })
            card.addView(TextView(this).apply {
                val total = Catalog.loadCached(this@MainActivity, reader.id)?.size
                text = reader.details + (if (total != null) "\nعدد التلاوات: $total" else "") +
                    (if (saved > 0) "\nالمحفوظ على الهاتف: $saved تلاوة" else "")
                textSize = 14f; setTextColor(0xFF5C665F.toInt()); setPadding(0, dp(6), 0, dp(8))
            })
            card.addView(Button(this).apply {
                text = if (saved > 0) "عرض التلاوات والاستماع" else "عرض التلاوات وتنزيل ما تريد"
                setOnClickListener { showTracks(reader) }
            }, LinearLayout.LayoutParams(-1, -2))
            if (saved > 0) {
                card.addView(Button(this).apply {
                    text = "حذف التلاوات المحفوظة لتوفير المساحة"
                    setOnClickListener { confirmDeleteReader(reader) }
                }, LinearLayout.LayoutParams(-1, -2))
            }
            card.addView(TextView(this).apply {
                text = "صفحة المصدر والتفاصيل"; textSize = 14f; setTextColor(0xFF456B5D.toInt()); setPadding(0, dp(10), 0, 0)
                setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Catalog.sourceUrl(reader.identifier)))) }
            })
            root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        }

        // بطاقة فيديوهات الشيخ محمود الشحات (تجويد)
        val savedVideos = Catalog.audioDir(this, VideoStore.READER_ID).walkTopDown()
            .count { it.isFile && !it.name.endsWith(".part") }
        val listedVideos = VideoStore.list(this).size
        val vCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }
        vCard.addView(TextView(this).apply {
            text = "فيديوهات الشيخ محمود الشحات أنور"; textSize = 20f; setTextColor(0xFF153B30.toInt())
        })
        vCard.addView(TextView(this).apply {
            text = "تجويد فقط • أضف الفيديو برابطه، ويُنزَّل مرة واحدة ويُحفظ على الهاتف للمشاهدة دون إنترنت" +
                (if (listedVideos > 0) "\nفي القائمة: $listedVideos • المحفوظ: $savedVideos" else "")
            textSize = 14f; setTextColor(0xFF5C665F.toInt()); setPadding(0, dp(6), 0, dp(8))
        })
        vCard.addView(Button(this).apply {
            text = "عرض الفيديوهات وإضافة رابط"
            setOnClickListener { showVideos() }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(vCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        setContent(scroll)
    }

    // ------------------------------------------------------------------ متابعة آخر تلاوة

    private fun lastPlayed(): Pair<File, Int>? {
        if (service?.currentFile != null) return null
        val sp = getSharedPreferences(PlaybackService.PLAYBACK_PREFS, MODE_PRIVATE)
        val path = sp.getString(PlaybackService.KEY_LAST_PATH, null) ?: return null
        val file = File(path)
        val audioRoot = File(filesDir, "audio").absolutePath + File.separator
        if (!file.isFile || !file.absolutePath.startsWith(audioRoot)) return null
        return file to sp.getInt(PlaybackService.KEY_LAST_POS, 0)
    }

    private fun resumeLast(file: File, pos: Int) {
        val s = service
        if (s == null) { statusText.text = "جارٍ تجهيز المشغّل، حاول بعد لحظة."; return }
        val readerId = file.absolutePath.removePrefix(File(filesDir, "audio").absolutePath + File.separator).substringBefore(File.separator)
        val tracks = Catalog.audioDir(this, readerId).walkTopDown()
            .filter { it.isFile && it.extension.lowercase() in Catalog.AUDIO_EXT }
            .sortedWith { a, b -> Catalog.compareNatural(a.name, b.name) }
            .toList()
        val idx = tracks.indexOfFirst { it.absolutePath == file.absolutePath }
        if (idx < 0) { statusText.text = "تعذر العثور على التلاوة."; return }
        s.playList(tracks, idx, pos)
        showHome()
    }

    // ------------------------------------------------------------------ قائمة التلاوات (مقطع مقطع)

    private fun showTracks(reader: Reader) {
        openReader = reader
        trackAdapter = null; dlButton = null; summaryText = null
        setContent(TextView(this).apply {
            text = "جارٍ تحميل قائمة التلاوات..."; textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFF263A33.toInt())
        })
        Thread {
            val result = runCatching { Catalog.loadCached(this, reader.id) ?: Catalog.fetch(this, reader) }
            runOnUiThread {
                if (openReader?.id != reader.id) return@runOnUiThread
                result.onSuccess { buildTrackScreen(reader, it) }.onFailure { showCatalogError(reader, it) }
            }
        }.start()
    }

    private fun showCatalogError(reader: Reader, e: Throwable) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24)) }
        box.addView(TextView(this).apply {
            text = "تعذر تحميل قائمة التلاوات.\n${e.localizedMessage ?: ""}\nتحقق من الإنترنت وحاول مرة أخرى."
            textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFF8B3A32.toInt())
        })
        box.addView(Button(this).apply { text = "إعادة المحاولة"; setOnClickListener { showTracks(reader) } })
        box.addView(Button(this).apply { text = "رجوع"; setOnClickListener { showHome() } })
        setContent(box)
    }

    private fun buildTrackScreen(reader: Reader, tracks: List<RemoteTrack>) {
        allTracks = tracks.sortedWith { a, b -> Catalog.compareNatural(a.name, b.name) }
        shownTracks = allTracks

        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(dark); setPadding(dp(8), dp(10), dp(14), dp(10))
        }
        top.addView(Button(this).apply { text = "رجوع"; setOnClickListener { showHome() } })
        top.addView(TextView(this).apply {
            text = reader.name; textSize = 17f; setTextColor(gold); setPadding(dp(12), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        screen.addView(top, LinearLayout.LayoutParams(-1, -2))

        summaryText = TextView(this).apply { textSize = 14f; setTextColor(0xFF37564B.toInt()); setPadding(dp(14), dp(8), dp(14), 0) }
        screen.addView(summaryText, LinearLayout.LayoutParams(-1, -2))
        dlButton = Button(this).apply { setOnClickListener { onDownloadButton(reader) } }
        screen.addView(dlButton, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), 0, dp(10), 0) })

        val search = EditText(this).apply {
            hint = "ابحث في التلاوات"; setSingleLine(true); setPadding(dp(14), dp(12), dp(14), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val q = Catalog.norm(s?.toString()?.trim().orEmpty())
                    shownTracks = if (q.isEmpty()) allTracks
                    else allTracks.filter {
                        Catalog.norm(label(it)).contains(q) ||
                            Catalog.norm(File(it.name).nameWithoutExtension).contains(q)
                    }
                    trackAdapter?.notifyDataSetChanged()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        screen.addView(search, LinearLayout.LayoutParams(-1, -2))

        val list = ListView(this)
        trackAdapter = TrackAdapter(reader)
        list.adapter = trackAdapter
        list.setOnItemClickListener { _, _, pos, _ -> onTrackClick(reader, shownTracks[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ -> onTrackLongClick(reader, shownTracks[pos]); true }
        screen.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContent(screen)
        rescanDownloaded()
        refreshTrackHeader()
        statusText.text = "اضغط على التلاوة لتنزيلها أو الاستماع إليها. اضغط مطوّلًا على المحفوظة لحذفها."
    }

    private fun job(reader: Reader, t: RemoteTrack) =
        DownloadService.Job(reader.id, t.name, t.size, Catalog.downloadUrl(reader.identifier, t.name), label(t))

    private fun onTrackClick(reader: Reader, t: RemoteTrack) {
        val file = Catalog.safeFile(this, reader.id, t.name) ?: return
        if (Catalog.isDownloaded(this, reader.id, t.name)) {
            val s = service
            if (s == null) { statusText.text = "جارٍ تجهيز المشغّل، حاول بعد لحظة."; return }
            val playable = shownTracks
                .filter { Catalog.isDownloaded(this, reader.id, it.name) }
                .mapNotNull { Catalog.safeFile(this, reader.id, it.name) }
            val idx = playable.indexOfFirst { it.absolutePath == file.absolutePath }
            if (idx >= 0) s.playList(playable, idx)
        } else {
            val d = dl
            if (d == null) { statusText.text = "جارٍ تجهيز خدمة التنزيل، حاول بعد لحظة."; return }
            if (t.size > 0 && filesDir.usableSpace < t.size + 50L * 1024 * 1024) {
                statusText.text = "المساحة الفارغة غير كافية لهذه التلاوة."; return
            }
            d.enqueue(listOf(job(reader, t)))
            statusText.text = "أُضيفت للتنزيل: ${label(t)}"
        }
    }

    private fun onTrackLongClick(reader: Reader, t: RemoteTrack) {
        if (!Catalog.isDownloaded(this, reader.id, t.name)) return
        val title = label(t)
        AlertDialog.Builder(this)
            .setTitle("حذف التلاوة؟")
            .setMessage(title)
            .setPositiveButton("حذف") { _, _ ->
                val f = Catalog.safeFile(this, reader.id, t.name)
                if (f != null) {
                    if (service?.currentFile?.absolutePath == f.absolutePath) service?.stopAndClose()
                    f.delete()
                }
                rescanDownloaded()
                trackAdapter?.notifyDataSetChanged(); refreshTrackHeader()
                statusText.text = "تم حذف التلاوة."
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun onDownloadButton(reader: Reader) {
        val d = dl ?: run { statusText.text = "جارٍ تجهيز خدمة التنزيل، حاول بعد لحظة."; return }
        if (d.isBusyFor(reader.id)) {
            d.cancelReader(reader.id)
            statusText.text = "تم إيقاف التنزيل. ما اكتمل منه محفوظ، ويمكنك الاستكمال لاحقًا."
            refreshTrackHeader()
            return
        }
        val remaining = allTracks.filter { !Catalog.isDownloaded(this, reader.id, it.name) }
        if (remaining.isEmpty()) { statusText.text = "كل التلاوات محفوظة."; return }
        val bytes = remaining.sumOf { it.size }
        if (bytes > 0 && filesDir.usableSpace < bytes + bytes / 10) {
            statusText.text = "المساحة الفارغة غير كافية. تحتاج نحو ${sizeLabel(bytes)}."
            return
        }
        AlertDialog.Builder(this)
            .setTitle("تنزيل المتبقي")
            .setMessage(
                "سيتم تنزيل ${remaining.size} تلاوة" + (if (bytes > 0) " (نحو ${sizeLabel(bytes)})" else "") +
                    " واحدة بعد الأخرى. يمكنك إغلاق التطبيق وسيكمل التنزيل في الخلفية، ويمكنك إيقافه في أي وقت."
            )
            .setPositiveButton("ابدأ") { _, _ ->
                d.enqueue(remaining.map { job(reader, it) })
                statusText.text = "بدأ التنزيل."
                refreshTrackHeader()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun refreshTrackHeader() {
        val r = openReader ?: return
        val btn = dlButton ?: return
        val total = allTracks.size
        val done = allTracks.count { downloadedSet.contains(it.name) }
        val busy = dl?.isBusyFor(r.id) == true
        summaryText?.text = "المحفوظ على الهاتف: $done من $total"
        btn.text = when {
            busy -> "إيقاف التنزيل"
            done >= total -> "كل التلاوات محفوظة"
            else -> "تنزيل المتبقي (${total - done})"
        }
        btn.isEnabled = busy || done < total
    }

    private fun sizeLabel(bytes: Long): String =
        if (bytes >= 1024L * 1024 * 1024) "%.1f جيجابايت".format(bytes / 1024.0 / 1024.0 / 1024.0)
        else "${bytes / 1024 / 1024} ميجابايت"

    private inner class TrackAdapter(private val reader: Reader) : BaseAdapter() {
        override fun getCount() = shownTracks.size
        override fun getItem(position: Int) = shownTracks[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
                addView(TextView(this@MainActivity).apply { textSize = 16f })
                addView(TextView(this@MainActivity).apply { textSize = 12f })
            }
            val title = row.getChildAt(0) as TextView
            val sub = row.getChildAt(1) as TextView
            val t = shownTracks[position]
            val key = "${reader.id}/${t.name}"
            val downloaded = downloadedSet.contains(t.name)
            val curPath = service?.currentFile?.absolutePath
            val prefix = Catalog.audioDir(this@MainActivity, reader.id).absolutePath + File.separator
            val current = downloaded && curPath != null && curPath == prefix + t.name
            val d = dl
            val mb = if (t.size > 0) " • ${t.size / 1024 / 1024} ميجابايت" else ""

            title.text = (if (current) "▶  " else "") + label(t)
            title.setTextColor(if (current) 0xFF0F6B4F.toInt() else 0xFF263A33.toInt())
            when {
                downloaded -> { sub.text = "✓ محفوظة$mb"; sub.setTextColor(0xFF2E7D5B.toInt()) }
                d?.current?.key == key -> {
                    val total = d?.currentTotal ?: 0L
                    val pct = if (total > 0) (d?.currentBytes ?: 0L) * 100 / total else 0L
                    sub.text = "⬇ جارٍ التنزيل $pct%"; sub.setTextColor(0xFFB07A00.toInt())
                }
                d?.isQueued(key) == true -> { sub.text = "⏳ في قائمة الانتظار"; sub.setTextColor(0xFF5C665F.toInt()) }
                else -> { sub.text = "اضغط للتنزيل$mb"; sub.setTextColor(0xFF5C665F.toInt()) }
            }
            row.setBackgroundColor(if (current) 0xFFE3EFE7.toInt() else Color.TRANSPARENT)
            return row
        }
    }

    private fun confirmDeleteReader(reader: Reader) {
        AlertDialog.Builder(this)
            .setTitle("حذف تلاوات ${reader.name}؟")
            .setMessage("سيتم حذف كل الملفات المحفوظة من الهاتف، ويمكنك تنزيلها مرة أخرى لاحقًا.")
            .setPositiveButton("حذف") { _, _ ->
                dl?.cancelReader(reader.id)
                val folder = Catalog.audioDir(this, reader.id)
                service?.currentFile?.let { if (it.absolutePath.startsWith(folder.absolutePath)) service?.stopAndClose() }
                folder.deleteRecursively()
                statusText.text = "تم حذف التلاوات."
                showHome()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ------------------------------------------------------------------ حالة التنزيل

    override fun onDownloadChanged() = refreshDownloadUi()

    private fun refreshDownloadUi() {
        val d = dl ?: return
        val busy = d.isBusy
        if (busy) {
            val cur = d.current
            if (cur != null) {
                val pct = if (d.currentTotal > 0) d.currentBytes * 100 / d.currentTotal else 0
                statusText.text = "جارٍ تنزيل: ${cur.shownName} — $pct% • المتبقي ${d.queuedCount} تلاوة"
            }
        }
        if (d.doneCount != lastDone) { lastDone = d.doneCount; rescanDownloaded() }
        if (wasBusy && !busy) rescanDownloaded()
        if (busy || wasBusy) {
            trackAdapter?.notifyDataSetChanged()
            videoAdapter?.notifyDataSetChanged()
            refreshTrackHeader()
        }
        if (wasBusy && !busy) {
            statusText.text = d.lastError
                ?: if (d.failedCount > 0) "اكتمل التنزيل مع تعذّر ${d.failedCount} تلاوة."
                else if (d.doneCount > 0) "اكتمل تنزيل ${d.doneCount} تلاوة."
                else "تم إيقاف التنزيل."
            if (openReader == null && !inVideos) showHome()
        }
        wasBusy = busy
    }

    // ------------------------------------------------------------------ شريط المشغّل

    override fun onStateChanged() {
        updatePlayerBar()
        trackAdapter?.notifyDataSetChanged()
    }

    private fun updatePlayerBar() {
        val s = service
        val file = s?.currentFile
        if (s == null || file == null) { playerBar.visibility = View.GONE; return }
        playerBar.visibility = View.VISIBLE
        playerTitle.text = s.currentTitle
        btnPlay.setImageResource(if (s.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        val dur = s.duration
        if (dur > 0) seekBar.max = dur
        if (!seekDragging) {
            seekBar.progress = s.position
            playerTime.text = "${fmt(s.position)} / ${fmt(dur)}" + sleepLabel(s)
        }
    }

    private fun sleepLabel(s: PlaybackService): String = when {
        s.sleepAfterTrack -> "  •  توقف بعد هذه التلاوة"
        s.sleepRemainingMs > 0 -> "  •  توقف بعد ${(s.sleepRemainingMs + 59_999) / 60_000} د"
        else -> ""
    }

    private fun showSleepDialog() {
        val s = service ?: return
        val labels = arrayOf("15 دقيقة", "30 دقيقة", "45 دقيقة", "ساعة", "بعد انتهاء التلاوة الحالية", "إلغاء المؤقّت")
        AlertDialog.Builder(this)
            .setTitle("مؤقّت النوم")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> s.setSleepTimer(15)
                    1 -> s.setSleepTimer(30)
                    2 -> s.setSleepTimer(45)
                    3 -> s.setSleepTimer(60)
                    4 -> s.sleepAfterCurrentTrack()
                    else -> s.setSleepTimer(0)
                }
                statusText.text = if (which == 5) "تم إلغاء مؤقّت النوم." else "تم ضبط مؤقّت النوم: ${labels[which]}."
            }
            .show()
    }

    private fun fmt(ms: Int): String {
        val total = ms / 1000
        val h = total / 3600; val m = (total % 3600) / 60; val sec = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    // ------------------------------------------------------------------ الفيديوهات

    private val videoReader = VideoStore.READER_ID

    private fun showVideos() {
        openReader = null; inVideos = true
        trackAdapter = null; dlButton = null; summaryText = null; videoAdapter = null
        videoList = VideoStore.list(this)

        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(dark); setPadding(dp(8), dp(10), dp(14), dp(10))
        }
        top.addView(Button(this).apply { text = "رجوع"; setOnClickListener { showHome() } })
        top.addView(TextView(this).apply {
            text = "فيديوهات الشيخ محمود الشحات (تجويد)"; textSize = 17f; setTextColor(gold); setPadding(dp(12), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        screen.addView(top, LinearLayout.LayoutParams(-1, -2))

        screen.addView(TextView(this).apply {
            text = "أضف رابط الفيديو مرة واحدة، ثم اضغط عليه ليُنزَّل ويُحفظ على الهاتف، وبعدها تشاهده دون إنترنت."
            textSize = 14f; setTextColor(0xFF37564B.toInt()); setPadding(dp(14), dp(10), dp(14), dp(4))
        }, LinearLayout.LayoutParams(-1, -2))
        screen.addView(Button(this).apply {
            text = "إضافة فيديو برابط"
            setOnClickListener { showAddVideoDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), 0, dp(10), 0) })

        if (videoList.isEmpty()) {
            screen.addView(TextView(this).apply {
                text = "لا توجد فيديوهات بعد.\nاضغط «إضافة فيديو برابط» والصق رابط mp4 مباشر أو رابط صفحة من archive.org."
                textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF5C665F.toInt()); setPadding(dp(24), dp(24), dp(24), dp(24))
            }, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            val list = ListView(this)
            videoAdapter = VideoAdapter()
            list.adapter = videoAdapter
            list.setOnItemClickListener { _, _, pos, _ -> onVideoClick(videoList[pos]) }
            list.setOnItemLongClickListener { _, _, pos, _ -> onVideoLongClick(videoList[pos]); true }
            screen.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContent(screen)
        statusText.text = "اضغط على الفيديو لتنزيله أو مشاهدته. اضغط مطوّلًا للحذف."
    }

    private fun showAddVideoDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val titleInput = EditText(this).apply { hint = "عنوان الفيديو (اختياري)"; setSingleLine(true) }
        val linkInput = EditText(this).apply {
            hint = "https://... رابط mp4 أو صفحة archive.org"; setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        box.addView(titleInput)
        box.addView(linkInput)
        AlertDialog.Builder(this)
            .setTitle("إضافة فيديو برابط")
            .setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                addVideoFromLink(titleInput.text.toString().trim(), linkInput.text.toString().trim())
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun addVideoFromLink(title: String, link: String) {
        if (!link.startsWith("https://")) { statusText.text = "الرابط لازم يبدأ بـ https://"; return }
        val ident = VideoStore.archiveIdentifier(link)
        if (ident != null && !VideoStore.hasVideoExt(link)) {
            statusText.text = "جارٍ جلب الفيديوهات من الصفحة..."
            Thread {
                val result = runCatching { VideoStore.fetchArchive(ident) }
                runOnUiThread {
                    result.onSuccess { items ->
                        val added = VideoStore.add(this, items)
                        if (inVideos) showVideos()
                        statusText.text = "تمت إضافة $added فيديو."
                    }.onFailure { statusText.text = "تعذر جلب الفيديوهات: ${it.localizedMessage ?: ""}" }
                }
            }.start()
            return
        }
        val name = title.ifBlank { VideoStore.nameFromUrl(link) }
        val added = VideoStore.add(this, listOf(VideoItem(VideoStore.idFor(link), name, link)))
        showVideos()
        statusText.text = if (added > 0) "تمت إضافة الفيديو." else "هذا الفيديو مضاف بالفعل."
    }

    private fun onVideoClick(item: VideoItem) {
        if (Catalog.isDownloaded(this, videoReader, item.fileName)) {
            val file = Catalog.safeFile(this, videoReader, item.fileName) ?: return
            service?.pause() // نوقف صوت التلاوة أثناء المشاهدة
            startActivity(
                Intent(this, VideoPlayerActivity::class.java)
                    .putExtra("path", file.absolutePath)
                    .putExtra("title", item.title)
            )
        } else {
            val d = dl ?: run { statusText.text = "جارٍ تجهيز خدمة التنزيل، حاول بعد لحظة."; return }
            d.enqueue(listOf(DownloadService.Job(videoReader, item.fileName, 0L, item.url, item.title)))
            statusText.text = "أُضيف للتنزيل: ${item.title}"
        }
    }

    private fun onVideoLongClick(item: VideoItem) {
        val saved = Catalog.isDownloaded(this, videoReader, item.fileName)
        val labels = if (saved) arrayOf("حذف الملف من الهاتف (يبقى في القائمة)", "إزالة من القائمة وحذف الملف")
        else arrayOf("إزالة من القائمة")
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setItems(labels) { _, which ->
                if (saved && which == 0) {
                    deleteVideoFile(item)
                } else {
                    deleteVideoFile(item)
                    VideoStore.remove(this, item.id)
                }
                showVideos()
                statusText.text = "تم."
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun deleteVideoFile(item: VideoItem) {
        val f = Catalog.safeFile(this, videoReader, item.fileName) ?: return
        f.delete()
        File(f.path + ".part").delete()
    }

    private inner class VideoAdapter : BaseAdapter() {
        override fun getCount() = videoList.size
        override fun getItem(position: Int) = videoList[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
                addView(TextView(this@MainActivity).apply { textSize = 16f; setTextColor(0xFF263A33.toInt()) })
                addView(TextView(this@MainActivity).apply { textSize = 12f })
            }
            val title = row.getChildAt(0) as TextView
            val sub = row.getChildAt(1) as TextView
            val item = videoList[position]
            val key = "$videoReader/${item.fileName}"
            val d = dl
            title.text = item.title
            when {
                Catalog.isDownloaded(this@MainActivity, videoReader, item.fileName) -> {
                    sub.text = "✓ محفوظ على الهاتف — اضغط للمشاهدة"; sub.setTextColor(0xFF2E7D5B.toInt())
                }
                d?.current?.key == key -> {
                    val total = d?.currentTotal ?: 0L
                    val pct = if (total > 0) (d?.currentBytes ?: 0L) * 100 / total else 0L
                    sub.text = "⬇ جارٍ التنزيل $pct%"; sub.setTextColor(0xFFB07A00.toInt())
                }
                d?.isQueued(key) == true -> { sub.text = "⏳ في قائمة الانتظار"; sub.setTextColor(0xFF5C665F.toInt()) }
                else -> { sub.text = "اضغط للتنزيل"; sub.setTextColor(0xFF5C665F.toInt()) }
            }
            return row
        }
    }

    // ------------------------------------------------------------------ مشاركة التطبيق

    private fun shareInstalledApk() {
        try {
            val source = File(applicationInfo.sourceDir)
            val shareDir = File(cacheDir, "shared").apply { mkdirs() }
            val apk = File(shareDir, "QuranListening.apk")
            source.inputStream().use { input -> apk.outputStream().use { output -> input.copyTo(output) } }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "تطبيق القرآن الكريم - استماع")
                putExtra(Intent.EXTRA_TEXT, "تطبيق للاستماع إلى التلاوات المجوّدة، صدقة جارية على أرواح المسلمين أجمعين.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "مشاركة تطبيق القرآن الكريم"))
        } catch (e: Exception) {
            statusText.text = "تعذرت مشاركة APK: ${e.localizedMessage}"
        }
    }
}
