package com.bakr.quranlisten

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** فيديو واحد: رابط مباشر يُنزَّل مرة واحدة ويُحفظ على الهاتف. */
data class VideoItem(val id: String, val title: String, val url: String) {
    val fileName: String get() = "$id.${VideoStore.extOf(url)}"
}

/** قائمة فيديوهات الشيخ محمود الشحات (تجويد) التي يضيفها المستخدم بالرابط. */
object VideoStore {
    const val READER_ID = "video_shahat"
    private const val PREFS = "videos"
    private const val KEY = "list"
    val VIDEO_EXT = setOf("mp4", "m4v", "webm", "3gp")
    private val ARCHIVE = Regex("""archive\.org/(?:details|download)/([^/?#]+)""")

    private fun extRaw(url: String): String =
        url.substringBefore('?').substringBefore('#').substringAfterLast('.', "").lowercase()

    fun extOf(url: String): String = extRaw(url).let { if (it in VIDEO_EXT) it else "mp4" }
    fun hasVideoExt(url: String): Boolean = extRaw(url) in VIDEO_EXT
    fun idFor(url: String): String = "v" + (url.hashCode().toLong() and 0xffffffffL).toString(16)
    fun archiveIdentifier(url: String): String? = ARCHIVE.find(url)?.groupValues?.get(1)

    fun nameFromUrl(url: String): String {
        val last = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
        val decoded = try { java.net.URLDecoder.decode(last, "UTF-8") } catch (_: Exception) { last }
        return decoded.substringBeforeLast('.').ifBlank { "فيديو" }
    }

    fun list(ctx: Context): List<VideoItem> = try {
        val arr = JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            VideoItem(o.getString("i"), o.getString("t"), o.getString("u"))
        }
    } catch (_: Exception) { emptyList() }

    private fun save(ctx: Context, items: List<VideoItem>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("i", it.id).put("t", it.title).put("u", it.url)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    /** يضيف الفيديوهات الجديدة فقط ويرجع عددها. */
    fun add(ctx: Context, items: List<VideoItem>): Int {
        val current = list(ctx).toMutableList()
        var added = 0
        for (item in items) {
            if (current.none { c -> c.url == item.url }) { current.add(item); added++ }
        }
        if (added > 0) save(ctx, current)
        return added
    }

    fun remove(ctx: Context, id: String) = save(ctx, list(ctx).filter { it.id != id })

    /** يجلب ملفات الفيديو (mp4/webm...) من صفحة archive.org (عملية شبكة: ليس على الخيط الرئيسي). */
    fun fetchArchive(identifier: String): List<VideoItem> {
        val conn = (URL("https://archive.org/metadata/$identifier").openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000; readTimeout = 40000; instanceFollowRedirects = true
            setRequestProperty("User-Agent", "QuranListening/1.0")
        }
        val text = try {
            if (conn.responseCode != 200) throw IOException("تعذر جلب الصفحة (HTTP ${conn.responseCode})")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally { conn.disconnect() }

        val files = JSONObject(text).optJSONArray("files") ?: throw IOException("لا توجد ملفات في هذه الصفحة")
        val all = (0 until files.length()).map { files.getJSONObject(it) }
            .filter { hasVideoExt(it.optString("name")) }
        val originals = all.filter { it.optString("source") == "original" }
        val chosen = if (originals.isNotEmpty()) originals else all
        if (chosen.isEmpty()) throw IOException("لم يتم العثور على ملفات فيديو (mp4) في هذه الصفحة")
        return chosen
            .sortedWith { a, b -> Catalog.compareNatural(a.optString("name"), b.optString("name")) }
            .map { o ->
                val name = o.getString("name")
                val url = Catalog.downloadUrl(identifier, name)
                val title = o.optString("title").trim().ifBlank { nameFromUrl(name) }
                VideoItem(idFor(url), title, url)
            }
    }
}
