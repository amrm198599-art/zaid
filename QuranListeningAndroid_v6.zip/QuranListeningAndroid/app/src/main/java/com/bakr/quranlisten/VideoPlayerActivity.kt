package com.bakr.quranlisten

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView

/** مشغّل فيديو بسيط للملفات المحفوظة على الهاتف. */
class VideoPlayerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path")
        if (path == null) { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val video = VideoView(this)
        val controller = MediaController(this)
        controller.setAnchorView(video)
        video.setMediaController(controller)
        video.setOnPreparedListener { it.start() }
        video.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "تعذر تشغيل هذا الفيديو.", Toast.LENGTH_LONG).show()
            finish()
            true
        }
        video.setVideoPath(path)

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        frame.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        setContentView(frame)
    }
}
